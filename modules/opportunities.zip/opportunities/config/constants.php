<?php
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * opportunity attachments folder from profile
 */
define('OPPORTUNITY_ATTACHMENTS_FOLDER', FCPATH . 'uploads/opportunity' . '/');
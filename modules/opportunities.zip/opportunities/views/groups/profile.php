<?php defined('BASEPATH') or exit('No direct script access allowed'); ?>
<div class="clearfix"></div>

<div class="clearfix mtop20"></div>

      <div class="table-responsive">

         <table class="table dt-table table-projects" data-order-col="2" data-order-type="desc">
            <thead>
               <tr>
                  <th><?php echo _l('profile_project_name'); ?></th>
                  <th><?php echo _l('profile_account'); ?></th>
                  <th><?php echo _l('profile_owner'); ?></th>
                  <th><?php echo _l('profile_probability'); ?></th>
                  <th><?php echo _l('profile_status'); ?></th>
                  <th><?php echo _l('profile_delivery_date'); ?></th>
                  <th><?php echo _l('profile_projected_sale_date'); ?></th>
                  <th><?php echo _l('datecreated'); ?></th>
                  
               </tr>
            </thead>
            <tbody>
               <?php 

               if(isset($opportunity_table) && !empty($opportunity_table)){
                  foreach ($opportunity_table as $k => $opportunity_tab) { 

                        $project_name = $opportunity_tab['project_name'];
    $isPerson = false;

    if ($project_name == '') {
        $project_name  = _l('no_company_view_profile');
        $isPerson = true;
    }

    $url = admin_url('opportunities/opportunity/' . $opportunity_tab['id']);

    $project_name = '<a href="' . admin_url('opportunities/opportunity/' . $opportunity_tab['id'] . '?group=opportunity_profile') . '">' . $project_name . '</a>';


    $status = $opportunity_tab['status'];
    if($status == 1){
        $show_status = 'Prospecting';
    }
    else if($status == 2){
        $show_status = 'Proposal Sent';
    }
    else if($status == 3){
        $show_status = 'Negotiating';
    }
    else if($status == 4){
        $show_status = 'Investigating';
    }
    else if($status == 5){
        $show_status = 'Closed';
    }

                     ?>
                     <tr>
                        <td><?php echo $project_name; ?></td>
                        <td><?= $opportunity_tab['company'] ?></td>
                        <td><?= $opportunity_tab['staffname'] ?></td>
                        <td><?= $opportunity_tab['probability'] ?> %</td>
                        <td><?= $show_status ?></td>   
                        <td><?= $opportunity_tab['delivery_date'] ?></td>
                        <td><?= $opportunity_tab['projected_sale_date'] ?></td>
                        <td><?= _dt($opportunity_tab['datecreated']) ?></td>
                     </tr>
                     <?php 
                  }
               }
               ?>
            </tbody>
         </table>
      </div>

<?php init_tail(); ?>
<script>
   $(function(){
     var CustomersServerParams = {};
     var oppo_id = "<?php echo $opportunity->id ?>";
     $.each($('._hidden_inputs._filters input'),function(){
        CustomersServerParams[$(this).attr('name')] = '[name="'+$(this).attr('name')+'"]';
     });
     CustomersServerParams['exclude_inactive'] = '[name="exclude_inactive"]:checked';
     var tAPI = initDataTable('.table-opportunities', admin_url+'opportunities/table_profile/'+oppo_id, [0], [0], CustomersServerParams,<?php echo hooks()->apply_filters('customers_table_default_order', json_encode(array(2,'asc'))); ?>);
     $('input[name="exclude_inactive"]').on('change',function(){
       tAPI.ajax.reload();
    });
  });
</script>
<?php $this->load->view('opportunities/opportunity_group'); ?>

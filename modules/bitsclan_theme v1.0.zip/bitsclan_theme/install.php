<?php



defined('BASEPATH') or exit('No direct script access allowed');



/**

 * The file is responsible for handing the chat installation

 */

$CI = &get_instance();



add_option('bitsclan_theme_customers', 1);

